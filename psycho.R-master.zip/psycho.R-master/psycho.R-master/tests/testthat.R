library(testthat)
library(psycho)

test_check("psycho")
