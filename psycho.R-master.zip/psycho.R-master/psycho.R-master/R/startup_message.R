# .onAttach <- function(libname, pkgname) {
#   packageStartupMessage("Note: Many functions of the 'psycho' package have been (improved and) moved to other packages of the new 'easystats' collection (https://github.com/easystats). If you don't find where a function is gone, ")
# }
